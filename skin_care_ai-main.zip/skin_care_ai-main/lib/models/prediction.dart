import 'dart:convert';

class PredictionResponse {
  String imagePath;
  final List<PredictionResult> result;

  PredictionResponse({
    required this.imagePath,
    required this.result,
  });

  // Factory method to create an instance from a JSON map
  factory PredictionResponse.fromJson(Map<String, dynamic> json) {
    var resultFromJson = json['result'] as List;
    List<PredictionResult> resultList =
        resultFromJson.map((item) => PredictionResult.fromJson(item)).toList();

    // Sort the result list in descending order based on the probability
    resultList.sort((a, b) => b.probability.compareTo(a.probability));

    return PredictionResponse(
      imagePath: json['image_path'],
      result: resultList,
    );
  }

  // Convert the instance to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'image_path': imagePath,
      'result': result.map((item) => item.toJson()).toList(),
    };
  }
}

class PredictionResult {
  final String predictionClass;
  final double probability;

  PredictionResult({
    required this.predictionClass,
    required this.probability,
  });

  // Factory method to create an instance from a JSON map
  factory PredictionResult.fromJson(Map<String, dynamic> json) {
    return PredictionResult(
      predictionClass: json['class'] as String,
      probability: (json['probability'] as num).toDouble(),
    );
  }

  // Convert the instance to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'class': predictionClass,
      'probability': probability,
    };
  }
}

// Helper function to parse the JSON string into the model
PredictionResponse parsePredictionResponse(String jsonString) {
  final Map<String, dynamic> jsonMap = json.decode(jsonString);
  return PredictionResponse.fromJson(jsonMap);
}
