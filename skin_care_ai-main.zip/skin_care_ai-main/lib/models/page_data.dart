import 'package:flutter/material.dart';

class PageData {
  final Widget widget;
  final String title;

  PageData({required this.widget, required this.title});
}
