import 'dart:io';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:skin_care_ai/models/prediction.dart';

class ResultPage extends StatefulWidget {
  final PredictionResponse? predictionResponse;

  const ResultPage({super.key, required this.predictionResponse});

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  late final PredictionResponse? _top3PredictionResult;

  @override
  void initState() {
    super.initState();

    if (widget.predictionResponse != null) {
      _top3PredictionResult = PredictionResponse(
        imagePath: widget.predictionResponse!.imagePath,
        result: [
          widget.predictionResponse!.result[2], // 3rd
          widget.predictionResponse!.result[0], // 1st
          widget.predictionResponse!.result[1], // 2nd
        ],
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return widget.predictionResponse != null
        ? SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Hero(
                  tag: 'image',
                  child: Image.file(
                    File(widget.predictionResponse!.imagePath),
                    width: double.infinity,
                    fit: BoxFit.contain,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 16,
                  ),
                  child: Card(
                    elevation: 8,
                    child: Padding(
                      padding: const EdgeInsets.all(
                        16,
                      ),
                      child: Text(
                        "We've identified the presence of ${widget.predictionResponse!.result.first.predictionClass} as a concern for your skin.",
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 8,
                    right: 8,
                  ),
                  child: SizedBox(
                    height: MediaQuery.of(context).size.height / 2.5,
                    child: BarChart(
                      BarChartData(
                        alignment: BarChartAlignment.spaceEvenly,
                        barTouchData: BarTouchData(
                          enabled: false,
                          touchTooltipData: BarTouchTooltipData(
                            fitInsideVertically: true,
                            getTooltipColor: (group) => Colors.transparent,
                            getTooltipItem: (
                              BarChartGroupData group,
                              int groupIndex,
                              BarChartRodData rod,
                              int rodIndex,
                            ) {
                              return BarTooltipItem(
                                "${_top3PredictionResult!.result[groupIndex].predictionClass}\n"
                                "${rod.toY.toString()}",
                                TextStyle(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .inverseSurface,
                                  fontWeight: FontWeight.bold,
                                ),
                              );
                            },
                          ),
                        ),
                        titlesData: FlTitlesData(
                          show: false,
                        ),
                        gridData: FlGridData(
                          show: false,
                        ),
                        borderData: FlBorderData(
                          show: false,
                        ),
                        maxY: _top3PredictionResult!.result
                                .map((result) => result.probability)
                                .reduce((a, b) => a > b ? a : b) +
                            0.2,
                        barGroups: _top3PredictionResult.result.map((result) {
                          return BarChartGroupData(
                            x: _top3PredictionResult.result.indexOf(result),
                            barRods: [
                              BarChartRodData(
                                toY: result.probability,
                                color: _top3PredictionResult.result
                                            .indexOf(result) ==
                                        0
                                    ? Colors.blue[200]
                                    : _top3PredictionResult.result
                                                .indexOf(result) ==
                                            1
                                        ? Colors.red[200]
                                        : Colors.amber[200],
                                width: MediaQuery.of(context).size.width / 5.5,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(
                                    6,
                                  ),
                                  topRight: Radius.circular(
                                    6,
                                  ),
                                ),
                              ),
                            ],
                            showingTooltipIndicators: [0],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 8,
                    bottom: 16,
                    right: 8,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                      ),
                      borderRadius: BorderRadius.all(
                        Radius.circular(
                          10,
                        ),
                      ),
                    ),
                    child: Table(
                      border: TableBorder.symmetric(
                        inside: BorderSide(
                          width: 1,
                        ),
                      ),
                      children: [
                        // Header Row
                        TableRow(
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.inverseSurface,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(
                                10,
                              ),
                              topRight: Radius.circular(
                                10,
                              ),
                            ),
                          ),
                          children: [
                            TableCell(
                              child: Padding(
                                padding: const EdgeInsets.all(
                                  8,
                                ),
                                child: Text(
                                  'Prediction',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            TableCell(
                              child: Padding(
                                padding: const EdgeInsets.all(
                                  8,
                                ),
                                child: Text(
                                  'Probability',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        // Data Rows
                        for (var result in widget.predictionResponse!.result)
                          TableRow(
                            children: [
                              TableCell(
                                child: Padding(
                                  padding: const EdgeInsets.all(
                                    8,
                                  ),
                                  child: Text(result.predictionClass),
                                ),
                              ),
                              TableCell(
                                child: Padding(
                                  padding: const EdgeInsets.all(
                                    8,
                                  ),
                                  child: Text(
                                    result.probability.toString(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        : Center(
            child: Text(
              'No Result Found',
            ),
          );
  }
}
