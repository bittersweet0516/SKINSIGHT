import 'package:flutter/material.dart';

class ListPage extends StatefulWidget {
  const ListPage({super.key});

  @override
  State<ListPage> createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  final List<Map<String, dynamic>> skinsData = [
    {
      'image': 'assets/images/oily.jpg',
      'details': {
        'Oily Skin': [],
        'Acne & Pores': [],
        'Salicylic Acid (BHA)': [
          'Helps exfoliate and unclog pores.',
          'Deeply cleanses pores and reduces their appearance.',
        ],
        'All Concern': [],
        'Niacinamide': [
          'Reduces inflammation and regulates sebum production.',
          'Strengthens the skin barrier and tightens pores.',
          'Reduces hyperpigmentation and brightens skin.',
          'Improves skin elasticity and reduces fine lines.',
        ],
        'Other Suitable Ingredients': [],
        'Acne': [
          "Tea Tree Oil – Known for its antibacterial properties.",
          "Benzoyl Peroxide – Kills acne-causing bacteria.",
        ],
        'Pores': [
          "Clay (e.g., Bentonite or Kaolin) – Absorbs excess oil and tightens pores.",
          "Charcoal – Helps to detoxify and minimize pores.",
        ],
        'Dark Spots': [
          "Vitamin C – Brightens dark spots and evens skin tone.",
          "Alpha Arbutin – Reduces dark spots and evens skin tone.",
        ],
        'Wrinkles': [
          "Retinol – Stimulates collagen production and smooths wrinkles.",
          "Peptides – Strengthen skin and reduce the appearance of wrinkles.",
        ],
      },
    },
    {
      'image': 'assets/images/dry.jpg',
      'details': {
        'Dry Skin': [],
        'Acne, Pores and Wrinkles': [],
        'Hyaluronic Acid': [
          'Keeps skin hydrated while treating acne.',
          'Hydrates and plumps the skin, reducing the appearance of pores.',
          'Hydrates and plumps the skin to reduce the appearance of wrinkles.',
        ],
        'Other Suitable Ingredients': [],
        'Acne': [
          'Salicylic Acid (gentle form) – Helps treat acne without over-drying.',
          'Aloe Vera – Soothes the skin and helps reduce inflammation.',
          'Zinc – Reduces acne inflammation and supports healing.',
        ],
        'Pores': [
          'Glycolic Acid – Exfoliates and encourages cell turnover, refining pores.',
          'Rosewater – Balances and tightens pores without stripping moisture.',
        ],
        'Dark Spots': [
          'Vitamin C – Evens out skin tone and fades dark spots.',
          'Licorice Extract – Brightens dark spots and reduces hyperpigmentation.',
          'Retinoids (in low concentration) – Promote cell turnover and fade dark spots.',
        ],
        'Wrinkles': [
          'Retinoids – Promote cell turnover and reduce wrinkles (use with caution).',
          'Ceramides – Strengthen the skin barrier and prevent moisture loss.',
        ],
      },
    },
    {
      'image': 'assets/images/combination.jpg',
      'details': {
        'Combination Skin': [],
        'Acne': [
          'Salicylic Acid – Works well to target acne-prone areas.',
          'Niacinamide – Balances oil production and helps with acne.',
          'Azelaic Acid – Reduces acne and improves skin texture.',
        ],
        'Pores': [
          'Niacinamide – Tightens pores and balances oil production.',
          'Glycolic Acid – Exfoliates and smoothens skin, reducing pore size.',
          'Salicylic Acid – Targets the pores in oily areas while maintaining hydration in dry zones.',
        ],
        'Dark Spots': [
          'Vitamin C – Reduces pigmentation and brightens the skin.',
          'Niacinamide – Evens skin tone and reduces hyperpigmentation.',
          'Alpha Arbutin – Lightens dark spots and helps with pigmentation issues.',
        ],
        'Wrinkles': [
          'Peptides – Boost skin’s natural elasticity and reduce fine lines.',
          'Centella Asiatica – Improves skin regeneration and reduces fine lines.',
          'Hyaluronic Acid – Provides deep hydration and plumps skin to reduce wrinkles.',
        ],
      },
    },
    {
      'image': 'assets/images/sensitive.jpg',
      'details': {
        'Sensitive Skin': [],
        'Acne': [
          'Azelaic Acid – Soothes irritation and reduces acne.',
          'Centella Asiatica – Reduces inflammation and promotes healing.',
          'Zinc – Soothes sensitive skin and reduces acne flare-ups.',
        ],
        'Pores': [
          'Niacinamide – Tightens pores and balances oil production.',
          'Glycolic Acid – Exfoliates and smoothens skin, reducing pore size.',
          'Salicylic Acid – Targets the pores in oily areas while maintaining hydration in dry zones.',
        ],
        'Dark Spots': [
          'Licorice Extract – Gently fades dark spots and evens tone.',
          'Niacinamide – Soothes the skin while fading dark spots.',
          'Vitamin C (gentle form) – Brightens skin without irritation.',
        ],
        'Wrinkles': [
          'Peptides – Boost skin’s natural elasticity and reduce fine lines.',
          'Centella Asiatica – Improves skin regeneration and reduces fine lines.',
          'Hyaluronic Acid – Provides deep hydration and plumps skin to reduce wrinkles.',
        ],
      },
    },
    {
      'image': 'assets/images/normal.jpg',
      'details': {
        'Normal Skin': [],
        'Acne': [
          'Salicylic Acid – Unclogs pores without causing dryness.',
          'Niacinamide – Balances oil production and calms inflammation.',
        ],
        'Pores': [
          'Niacinamide – Tightens pores and regulates oil.',
          'Glycolic Acid – Gently exfoliates and refines pores.',
          'Hyaluronic Acid – Helps plump skin, making pores less noticeable.',
        ],
        'Dark Spot': [
          'Vitamin C – Brightens and fades dark spots.',
          'Niacinamide – Lightens pigmentation and improves skin tone.',
          'Alpha Arbutin – Lightens hyperpigmentation and evens tone.',
        ],
        'Wrinkles': [
          'Retinol – Reduces wrinkles and boosts collagen production.',
          'Peptides – Support the skin’s structure and reduce signs of aging.',
          'Hyaluronic Acid – Adds hydration and smooths wrinkles.',
        ],
      },
    },
  ];

  bool isDetails = false;
  bool isAnimating = false;
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (isDetails) {
          setState(() {
            isDetails = false;
            isAnimating = true;

            Future.delayed(
              Duration(
                milliseconds: 501,
              ),
              () {
                setState(() {
                  isAnimating = false;
                });
              },
            );
          });
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(
          16,
        ),
        child: Stack(
          children: [
            Column(
              children: [
                Text(
                  "Skin Care Ingredients for Different Skin Concerns & Types",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: skinsData.length,
                    itemBuilder: (context, index) {
                      return Card(
                        elevation: 8,
                        margin: const EdgeInsets.symmetric(
                          vertical: 16,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            20,
                          ),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(
                              20,
                            ),
                            onTap: () {
                              setState(() {
                                isDetails = true;
                                isAnimating = true;
                                selectedIndex = index;

                                Future.delayed(
                                  Duration(
                                    milliseconds: 501,
                                  ),
                                  () {
                                    setState(() {
                                      isAnimating = false;
                                    });
                                  },
                                );
                              });
                            },
                            child: Image.asset(
                              skinsData[index]['image'],
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            Center(
              child: AnimatedContainer(
                curve: Curves.easeInOut,
                duration: Duration(
                  milliseconds: 500,
                ), // Animation duration
                width: isDetails ? MediaQuery.sizeOf(context).width : 0,
                height: isDetails ? MediaQuery.sizeOf(context).height : 0,
                child: Card(
                  elevation: 50,
                  child: isAnimating
                      ? SizedBox()
                      : Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                left: 16,
                                right: 4,
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    skinsData[selectedIndex]['details']
                                        .entries
                                        .first
                                        .key,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      setState(() {
                                        isDetails = false;
                                        isAnimating = true;

                                        Future.delayed(
                                          Duration(
                                            milliseconds: 501,
                                          ),
                                          () {
                                            setState(() {
                                              isAnimating = false;
                                            });
                                          },
                                        );
                                      });
                                    },
                                    icon: Icon(
                                      Icons.close,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: SingleChildScrollView(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                    left: 16,
                                    right: 16,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      for (var entry in skinsData[selectedIndex]
                                              ['details']
                                          .entries
                                          .skip(1)) ...[
                                        Text(
                                          entry.key,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        for (var item in entry.value)
                                          Row(
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  left: 8,
                                                ),
                                                child: Text(
                                                  "●",
                                                ),
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                    left: 16,
                                                  ),
                                                  child: Text(
                                                    item,
                                                    softWrap: true,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                      ],
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(
                                8,
                              ),
                              child: SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Theme.of(context)
                                        .colorScheme
                                        .inversePrimary,
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(
                                          10,
                                        ),
                                      ),
                                    ),
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      isDetails = false;
                                      isAnimating = true;

                                      Future.delayed(
                                        Duration(
                                          milliseconds: 501,
                                        ),
                                        () {
                                          setState(() {
                                            isAnimating = false;
                                          });
                                        },
                                      );
                                    });
                                  },
                                  child: Text(
                                    'Close',
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .inverseSurface,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
