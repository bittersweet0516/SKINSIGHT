import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> images = [
    "assets/images/1.jpg",
    "assets/images/2.jpg",
    "assets/images/3.jpg",
    "assets/images/4.jpg",
    "assets/images/5.jpg",
  ];
  final List<String> welcomeTexts = [
    "Hi! Welcome to SKINSIGHT!",
    "We’re here to help you identify and understand your skin concerns with ease.",
    "Let us guide you through the process:",
    "Important Notes:",
    "Let SKINSIGHT help you achieve better insights into your skin!",
  ];
  final List<String> welcomeSteps = [
    "Navigate to the Scan page.",
    "Choose whether to take a picture or upload one from your gallery.",
    "Submit the selected photo and wait for your results!",
  ];

  final List<String> welcomeImportantNotes = [
    "Ensure the photo is a clear and well-lit image of your face only.",
    "Avoid wearing accessories like glasses, and refrain from including friends, family, or full-body shots to ensure accurate results.",
  ];
  final List<String> pros = [
    "Pros:",
    "Healthy Skin Barrier: A consistent skincare routine can protect the skin's barrier and keep it hydrated.",
    "Improved Appearance: Proper skincare can reduce wrinkles, acne, dark spots, and other concerns over time.",
    "Confidence Boost: Healthy, clear skin can enhance self-esteem and overall confidence.",
    "Prevention: Regular use of SPF and other treatments can prevent long-term damage, like sunspots and premature aging.",
  ];
  final List<String> cons = [
    "Cons:",
    "Time-Consuming: A multi-step routine can take time, and some people may find it overwhelming to stick to.",
    "Expense: High-quality skincare products can be costly, and over time, the expenses may add up.",
    "Sensitivity Reactions: Some products, like acids or retinoids, can irritate the skin, especially if not used properly.",
    "Trial and Error: Finding the right routine may require trying multiple products, which can",
  ];
  final List<String> dos = [
    "Do's:",
    "Do Use Sunscreen: SPF 30+ daily is nonnegotiable to prevent UV damage and premature aging.",
    "Do Cleanse Regularly: Morning and night to remove dirt, oil, and makeup.",
    "Do Moisturize: Even if you have oily skin,moisturizing keeps the skin barrier healthy.",
    "Do Patch Test: Always patch test new products to prevent reactions.",
    "Do Exfoliate (But Not Daily): Exfoliate 1-3 times a week to remove dead skin cells, but don't overdo it.",
  ];
  final List<String> donts = [
    "Don'ts:",
    "Don't Skip Sunscreen: Even on cloudy days or if you're indoors, as UV rays can penetrate windows.",
    "Don't Over-Exfoliate: Too much exfoliation can cause sensitivity, redness, and breakouts.",
    "Don't Use Too Many Actives: Mixing too many active ingredients can overwhelm the skin and cause irritation.",
    "Don't Use Hot Water: Hot water can strip the skin of its natural oils. Stick to lukewarm water when cleansing.",
    "Don't Touch Your Face: Avoid touching your face throughout the day to prevent transferring bacteria and oils.",
  ];
  final List<String> tips = [
    "Choose the Right Cleanser:",
    "Avoid Harsh Cleansers: Stay away from cleansers with high alcohol content or sulfates, as they can strip away natural oils and disrupt the skin barrier.",
    "Cleanse Twice Daily:",
    "Don't Over-Cleanse: Overwashing can lead to irritation or cause the skin to overproduce oil, especially for oily skin types.",
    "Pat Skin Dry: Instead of rubbing, gently pat your skin with a soft towel to avoid unnecessary irritation.",
  ];
  final List<String> tip1Details = [
    "Oily skin: Opt for gel-based or foaming cleansers.",
    "Dry skin: Cream or milk-based cleansers work best.",
    "Sensitive skin: Look for fragrance-free and gentle formulas.",
    "Acne-prone skin: Cleansers with salicylic acid or benzoyl peroxide can help.",
  ];
  final List<String> tip3Details = [
    "Morning to remove oils and debris from the night.",
    "Night to cleanse off makeup, dirt, and pollution.",
  ];
  final List<String> methods = [
    "Start Slow: Begin with a lower concentration (0.25%-0.5%) to let your skin acclimate. Use it 2-3 times a week.",
    "Night Application: Retinol increases skin sensitivity to the sun, so it's best used at night.",
    "Apply to Dry Skin: After cleansing, wait for your skin to fully dry before applying retinol to minimize irritation.",
    "Follow with Moisturizer: Retinol can be drying, so use a hydrating moisturizer afterward to soothe the skin.",
    "Avoid Mixing with Strong Actives: Don't mix retinol with other strong actives like AHAs/BHAs or vitamin C on the same night, as it can lead to irritation.",
    "Consistency is Key: It may take weeks to see visible improvements, so be patient and consistent.",
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ImageSlideshow(
          autoPlayInterval: 5000,
          isLoop: true,
          children: [
            ...images.map(
              (item) => _buildImage(item),
            ),
          ],
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(
                8.0,
              ),
              child: Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Card(
                      elevation: 8,
                      child: Padding(
                        padding: const EdgeInsets.only(
                          left: 8.0,
                          top: 8.0,
                          bottom: 8.0,
                          right: 30.0,
                        ),
                        child: Column(
                          children: [
                            ...welcomeTexts
                                .take(2)
                                .map((item) => _buildBulletPoint(item)),
                            SizedBox(
                              height: 16,
                            ),
                            ...welcomeTexts
                                .sublist(2, 3)
                                .map((item) => _buildBulletPoint(item)),
                            ...welcomeSteps.map((item) => _buildBulletPoint(
                                  item,
                                  24,
                                )),
                            SizedBox(
                              height: 16,
                            ),
                            ...welcomeTexts
                                .sublist(3, 4)
                                .map((item) => _buildBulletPoint(item)),
                            ...welcomeImportantNotes
                                .map((item) => _buildBulletPoint(
                                      item,
                                      24,
                                    )),
                            SizedBox(
                              height: 16,
                            ),
                            ...welcomeTexts
                                .sublist(welcomeTexts.length - 1)
                                .map((item) => _buildBulletPoint(item)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Card(
                      elevation: 8,
                      child: Padding(
                        padding: EdgeInsets.all(
                          16.0,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ExpansionTile(
                              collapsedShape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              shape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              tilePadding: EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              childrenPadding: EdgeInsets.only(
                                left: 8,
                                right: 16,
                                bottom: 16,
                              ),
                              title: Text(
                                "Pros and Cons of Skincare",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              children: [
                                ...pros
                                    .take(1)
                                    .map((item) => _buildBulletPoint(item, 0)),
                                ...pros
                                    .sublist(1, pros.length - 1)
                                    .map((item) => _buildBulletPoint(item)),
                                ...cons
                                    .take(1)
                                    .map((item) => _buildBulletPoint(item, 0)),
                                ...cons
                                    .sublist(1, cons.length - 1)
                                    .map((item) => _buildBulletPoint(item)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Card(
                      elevation: 8,
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ExpansionTile(
                              collapsedShape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              shape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              tilePadding: EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              childrenPadding: EdgeInsets.only(
                                left: 8,
                                right: 16,
                                bottom: 16,
                              ),
                              title: Text(
                                "Do's and Don'ts in a Skincare Routine",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              children: [
                                ...dos
                                    .take(1)
                                    .map((item) => _buildBulletPoint(item, 0)),
                                ...dos
                                    .sublist(1, dos.length - 1)
                                    .map((item) => _buildBulletPoint(item)),
                                ...donts
                                    .take(1)
                                    .map((item) => _buildBulletPoint(item, 0)),
                                ...donts
                                    .sublist(1, donts.length - 1)
                                    .map((item) => _buildBulletPoint(item)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Card(
                      elevation: 8,
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ExpansionTile(
                              collapsedShape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              shape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              tilePadding: EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              childrenPadding: EdgeInsets.only(
                                left: 8,
                                right: 16,
                                bottom: 16,
                              ),
                              title: Text(
                                "Skin Care Cleanser Tips",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              children: [
                                ...tips
                                    .take(1)
                                    .map((item) => _buildBulletPoint(item)),
                                ...tip1Details.map(
                                    (item) => _buildBulletPoint(item, 24, '○')),
                                ...tips
                                    .sublist(1, 3)
                                    .map((item) => _buildBulletPoint(item)),
                                ...tip3Details.map(
                                    (item) => _buildBulletPoint(item, 24, '○')),
                                ...tips
                                    .sublist(tips.length - 1)
                                    .map((item) => _buildBulletPoint(item)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: Card(
                      elevation: 8,
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ExpansionTile(
                              collapsedShape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              shape: RoundedRectangleBorder(
                                side: BorderSide.none,
                              ),
                              tilePadding: EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              childrenPadding: EdgeInsets.only(
                                left: 8,
                                right: 16,
                                bottom: 16,
                              ),
                              title: Text(
                                "Retinol Methods",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              children: [
                                ...methods
                                    .map((item) => _buildBulletPoint(item)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildImage(String imagePath) {
    return Image.asset(
      imagePath,
      fit: BoxFit.cover,
    );
  }

  Widget buildCard(
      String title, List<String> primaryItems, List<String> secondaryItems,
      [List<String>? details]) {
    return SizedBox(
      width: double.infinity,
      child: Card(
        elevation: 8,
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ExpansionTile(
                collapsedShape: RoundedRectangleBorder(
                  side: BorderSide.none,
                ),
                shape: RoundedRectangleBorder(
                  side: BorderSide.none,
                ),
                tilePadding: EdgeInsets.symmetric(
                  horizontal: 8,
                ),
                childrenPadding: EdgeInsets.only(
                  left: 8,
                  right: 16,
                  bottom: 16,
                ),
                title: Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                children: [
                  ...primaryItems
                      .take(1)
                      .map((item) => _buildBulletPoint(item, 0)),
                  ...primaryItems
                      .sublist(1, primaryItems.length - 1)
                      .map((item) => _buildBulletPoint(item)),
                  if (secondaryItems.isNotEmpty) ...[
                    ...secondaryItems
                        .take(1)
                        .map((item) => _buildBulletPoint(item, 0)),
                    ...secondaryItems
                        .sublist(1, secondaryItems.length - 1)
                        .map((item) => _buildBulletPoint(item)),
                  ],
                  if (details != null)
                    ...details.map(
                      (item) => _buildBulletPoint(item, 24, '○'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBulletPoint(String text, [double? padding, String? bullet]) {
    List<String> subTitle = [
      ...welcomeTexts,
      pros[0],
      cons[0],
      dos[0],
      donts[0]
    ];

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle.contains(text)
            ? SizedBox.shrink()
            : Padding(
                padding: EdgeInsets.only(
                  left: padding ?? 8,
                ),
                child: Text(
                  bullet ?? '●',
                ),
              ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              left: padding ?? 16,
            ),
            child: Text(
              text,
              softWrap: true,
            ),
          ),
        ),
      ],
    );
  }
}
