import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skin_care_ai/models/prediction.dart';

class ScanPage extends StatefulWidget {
  final Function(PredictionResponse response) onSuccess;

  const ScanPage({
    super.key,
    required this.onSuccess,
  });

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  final ImagePicker _imagePicker = ImagePicker();
  final String _imagePathKey = 'picked_image_path';

  bool _isUploadImageLoading = false;

  XFile? _pickedImage;

  @override
  void initState() {
    super.initState();

    _loadSavedImage();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _isUploadImageLoading
          ? CircularProgressIndicator()
          : Padding(
              padding: const EdgeInsets.all(
                16,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Center(
                      child: _pickedImage == null
                          ? Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 20,
                              ),
                              child: Placeholder(
                                color: Colors.grey,
                                strokeWidth: 1,
                              ),
                            )
                          : InkWell(
                              onTap: () {
                                show();
                              },
                              child: Card(
                                elevation: 8,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                    10,
                                  ),
                                  child: Hero(
                                    tag: 'image',
                                    child: Image.file(
                                      File(_pickedImage!.path),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: _pickedImage == null
                        ? MainAxisAlignment.center
                        : MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: _pickedImage == null
                            ? MediaQuery.of(context).size.width * 0.9
                            : MediaQuery.of(context).size.width * 0.43,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(
                                  10,
                                ),
                              ),
                            ),
                          ),
                          onPressed: () {
                            show();
                          },
                          child: Text(
                            _pickedImage == null
                                ? 'Upload Image'
                                : 'Reupload Image',
                          ),
                        ),
                      ),
                      Visibility(
                        visible: _pickedImage != null,
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.43,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(
                                    10,
                                  ),
                                ),
                              ),
                            ),
                            onPressed: () {
                              postToPredictApi();
                            },
                            child: Text(
                              'Submit',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  show() {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: SizedBox(
            width: double.infinity,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildModalBottomSheetContentWidget(
                  'Take Photo',
                  () async {
                    await _getImage(
                      ImageSource.camera,
                    );
                  },
                ),
                _buildModalBottomSheetContentWidget(
                  'Select from Gallery',
                  () async {
                    await _getImage(
                      ImageSource.gallery,
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _getImage(ImageSource source) async {
    Navigator.pop(context);

    setState(() {
      _isUploadImageLoading = true;
    });

    _pickedImage = await _imagePicker.pickImage(
      source: source,
    );

    if (_pickedImage != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_imagePathKey, _pickedImage!.path);
    } else {
      await _loadSavedImage();
    }

    setState(() {
      _isUploadImageLoading = false;
    });
  }

  Future<void> _loadSavedImage() async {
    setState(() {
      _isUploadImageLoading = true;
    });

    final prefs = await SharedPreferences.getInstance();
    final savedImagePath = prefs.getString(_imagePathKey);

    if (savedImagePath != null && File(savedImagePath).existsSync()) {
      setState(() {
        _pickedImage = XFile(savedImagePath);
      });
    }

    setState(() {
      _isUploadImageLoading = false;
    });
  }

  Widget _buildModalBottomSheetContentWidget(String text, Function() onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        color: Theme.of(context).colorScheme.surface,
        child: ListTile(
          title: Center(
            child: Text(
              text,
            ),
          ),
        ),
      ),
    );
  }

  Future<void> postToPredictApi() async {
    if (_pickedImage == null) {
      return;
    }

    try {
      // Convert XFile to File
      final file = File(_pickedImage!.path);

      // Create a MultipartRequest
      final uri = Uri.http('10.0.2.2:5000', '/predict');
      final request = http.MultipartRequest('POST', uri);

      // Attach the file
      request.files.add(
        http.MultipartFile(
          'file',
          file.readAsBytes().asStream(),
          file.lengthSync(),
          filename: _pickedImage!.path.split('/').last, // Use the file name
        ),
      );

      // Send the request
      final response = await request.send();

      // Handle the response
      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        PredictionResponse predictionResponse =
            parsePredictionResponse(responseBody);
        predictionResponse.imagePath = _pickedImage!.path;

        widget.onSuccess(predictionResponse);
      }
    } catch (e) {
      print('Error uploading file: $e');
    }
  }
}
