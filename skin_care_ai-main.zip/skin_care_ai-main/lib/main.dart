import 'package:flutter/material.dart';
import 'package:skin_care_ai/models/prediction.dart';
import 'package:skin_care_ai/views/list.dart';
import 'package:skin_care_ai/views/result.dart';
import 'package:skin_care_ai/views/scan.dart';
import 'models/page_data.dart';
import 'views/home.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SKINSIGHT',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late final List<PageData> _pagesData;

  int _selectedIndex = 0;
  PredictionResponse? _predictionResponse;

  @override
  void initState() {
    super.initState();

    _pagesData = [
      PageData(
        widget: HomePage(),
        title: 'SKINSIGHT',
      ),
      PageData(
        widget: ScanPage(onSuccess: (predictionResponse) {
          setState(() {
            _predictionResponse = predictionResponse;
            _selectedIndex = 2;
          });
        }),
        title: 'Scan',
      ),
      PageData(
        widget: Builder(
          builder: (context) => ResultPage(
            predictionResponse: _predictionResponse,
          ),
        ),
        title: 'Result',
      ),
      PageData(
        widget: ListPage(),
        title: 'List',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Center(
          child: Text(
            _pagesData[_selectedIndex].title,
          ),
        ),
      ),
      body: _pagesData[_selectedIndex].widget,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: Colors.grey[300]!,
              blurRadius: 50,
            ),
          ],
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(
                _selectedIndex == 0 ? Icons.home_rounded : Icons.home_outlined,
              ),
              label: _pagesData[0].title,
            ),
            BottomNavigationBarItem(
              icon: Icon(
                _selectedIndex == 1
                    ? Icons.camera_alt_rounded
                    : Icons.camera_alt_outlined,
              ),
              label: _pagesData[1].title,
            ),
            BottomNavigationBarItem(
              icon: Icon(
                _selectedIndex == 2
                    ? Icons.analytics_rounded
                    : Icons.analytics_outlined,
              ),
              label: _pagesData[2].title,
            ),
            BottomNavigationBarItem(
              icon: Icon(
                _selectedIndex == 3
                    ? Icons.article_rounded
                    : Icons.article_outlined,
              ),
              label: _pagesData[3].title,
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
}
