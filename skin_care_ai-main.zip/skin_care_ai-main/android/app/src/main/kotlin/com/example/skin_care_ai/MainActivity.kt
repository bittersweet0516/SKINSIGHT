package com.example.skin_care_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
